package exception;

public class BirthdayException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public BirthdayException(String message) {
		super(message);
	}

}
