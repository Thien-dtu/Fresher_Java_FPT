package connect_jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectJDBC {
/**
 * Hàm kết nối với database
 * @author DucNH59
 * @date 2023-02-07
 * @return
 */
	public static Connection getConnection() {
		final String USER = "sa";
		final String PASSWORD = "123";
		final String URL = "jdbc:sqlserver://localhost:1433;databaseName=Assignment_Candidate_Managerment;user=" + USER
				+ ";password=" + PASSWORD;
		Connection connection = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(URL);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

}
